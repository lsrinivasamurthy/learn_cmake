#include <iostream>
#include <console.hpp>

int main() {
    console::writeString("Hello World !!!");
    return 0;
}
