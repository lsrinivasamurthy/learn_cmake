//
// Created by lkk5kor on 20/2/24.
//

#ifndef SUBFOLDERPROJECT_CONSOLE_HPP
#define SUBFOLDERPROJECT_CONSOLE_HPP

#include "include/Input.hpp"
#include "include/Output.hpp"

#endif //SUBFOLDERPROJECT_CONSOLE_HPP
