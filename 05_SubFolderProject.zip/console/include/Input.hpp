//
// Created by lkk5kor on 20/2/24.
//

#ifndef SUBFOLDERPROJECT_INPUT_HPP
#define SUBFOLDERPROJECT_INPUT_HPP

#include "string"

namespace console
{
    ::std::string getString();
    ::std::string prompt(::std::string query);
}
#endif //SUBFOLDERPROJECT_INPUT_HPP
