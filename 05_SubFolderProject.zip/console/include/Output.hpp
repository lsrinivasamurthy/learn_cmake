//
// Created by lkk5kor on 20/2/24.
//

#ifndef SUBFOLDERPROJECT_OUTPUT_HPP
#define SUBFOLDERPROJECT_OUTPUT_HPP

#include "string"

namespace console
{
    void writeString(::std::string str);
}

#endif //SUBFOLDERPROJECT_OUTPUT_HPP
